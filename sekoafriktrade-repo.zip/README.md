# SékoAfrikTrade — Landing page + Netlify Functions

## Structure de ce dossier (à respecter telle quelle sur GitHub)

```
.
├── afrimarket-landing-final.html   ← la landing page (devient la page d'accueil grâce à netlify.toml)
├── package.json                     ← dépendances pour les Netlify Functions
├── netlify.toml                     ← configuration Netlify (chemin des fonctions + redirection)
└── netlify/
    └── functions/
        └── ga4-stats.js              ← fonction qui récupère les stats Google Analytics 4
```

## Variables d'environnement requises (déjà configurées sur Netlify)
- `GA4_SERVICE_ACCOUNT_KEY` — JSON complet de la clé de compte de service Google
- `GA4_PROPERTY_ID` — `541303237`

## Après avoir uploadé ce dossier sur GitHub
1. Va sur Netlify → ton site `sekoafriktrade` → **Project configuration** → **Build & deploy** → **Continuous deployment**
2. **Link site to Git** (ou équivalent) → connecte ce repo GitHub
3. Build command : laisse vide (pas besoin de build, c'est un site statique + functions)
4. Publish directory : `.`
5. Déploie

Une fois connecté, chaque modification que tu pousseras sur GitHub redéploiera automatiquement le site avec les Functions actives.
